package com.ibm.training;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginHrApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginHrApplication.class, args);
	}

}
