package com.ibm.training;

import org.springframework.data.repository.CrudRepository;

public interface LoginRepo extends CrudRepository<HR, String>
{

}
