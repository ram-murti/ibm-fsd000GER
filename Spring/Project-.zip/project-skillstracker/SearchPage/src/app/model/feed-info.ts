export interface FeedInfo {
    title: string,
    link: string,
    author: string,
    description: string,
    image: string
  }