package com.ibm.training;

import org.springframework.data.repository.CrudRepository;

public interface SkillsInfoRepository extends CrudRepository<SkillsInfo, String> 
{
	
}
