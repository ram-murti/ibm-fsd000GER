package com.ibm.training;


public class SkillsTrackerApplicationTests {

	public void contextLoads() {
	}

}
