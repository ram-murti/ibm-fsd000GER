import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-skills-input',
  templateUrl: './skills-input.component.html',
  styleUrls: ['./skills-input.component.css']
})
export class SkillsInputComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
